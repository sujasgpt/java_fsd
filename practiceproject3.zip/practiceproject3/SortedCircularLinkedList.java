package practiceproject3;

public class SortedCircularLinkedList {
    
    Node head;

    static class Node {
        int data;
        Node next;
        Node(int d) {
            data = d;
            next = null;
        }
    }

    // Function to insert a new node in a sorted circular linked list
    void sortedInsert(Node new_node) {
        Node current = head;

        // If the list is empty, set the new node as head and point its next to itself
        if (current == null) {
            new_node.next = new_node;
            head = new_node;
        }

        // If the new node's data is less than the head's data, insert it before the head
        else if (new_node.data < current.data) {
            while (current.next != head) {
                current = current.next;
            }
            current.next = new_node;
            new_node.next = head;
            head = new_node;
        }

        // Traverse the list and find the appropriate position for the new node
        else {
            while (current.next != head && current.next.data < new_node.data) {
                current = current.next;
            }
            new_node.next = current.next;
            current.next = new_node;
        }
    }

    // Function to print the contents of the sorted circular linked list
    void printList() {
        Node current = head;
        if (head != null) {
            do {
                System.out.print(current.data + " ");
                current = current.next;
            }
            while (current != head);
        }
    }

    // Main method to test the above functions
    public static void main(String[] args) {
        SortedCircularLinkedList list = new SortedCircularLinkedList();

        // Create a sorted circular linked list
        list.sortedInsert(new Node(5));
        list.sortedInsert(new Node(10));
        list.sortedInsert(new Node(12));
        list.sortedInsert(new Node(15));
        list.sortedInsert(new Node(20));

        // Print the sorted circular linked list
        System.out.println("Sorted Circular Linked List:");
        list.printList();
    }
}