package practiceproject3;

public class RightRotateArray {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int n = array.length;
        int k = 5;
        
        // Print the original array
        System.out.println("Original Array:");
        for (int i = 0; i < n; i++) {
            System.out.print(array[i] + " ");
        }
        
        // Right rotate the array by k steps
        for (int i = 0; i < k; i++) {
            int temp = array[n - 1];
            for (int j = n - 1; j > 0; j--) {
                array[j] = array[j - 1];
            }
            array[0] = temp;
        }
        
        // Print the rotated array
        System.out.println("\nRotated Array:");
        for (int i = 0; i < n; i++) {
            System.out.print(array[i] + " ");
        }
    }
}
