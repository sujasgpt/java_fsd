package practiceproject3;

public class DoublyLinkedList {
    
    Node head; // Head of the doubly linked list

    // Node class
    static class Node {
        int data;
        Node prev;
        Node next;

        Node(int d) {
            data = d;
            prev = null;
            next = null;
        }
    }

    // Method to traverse the doubly linked list in forward direction
    void traverseForward() {
        Node current = head;

        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }

        System.out.println();
    }

    // Method to traverse the doubly linked list in backward direction
    void traverseBackward() {
        Node current = head;

        // Get the last node of the doubly linked list
        while (current != null && current.next != null) {
            current = current.next;
        }

        // Traverse backward from the last node
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.prev;
        }

        System.out.println();
    }

    // Main method to test the doubly linked list traversal
    public static void main(String[] args) {
        DoublyLinkedList list = new DoublyLinkedList();

        // Create the doubly linked list
        list.head = new Node(1);
        Node second = new Node(2);
        Node third = new Node(3);

        // Connect the nodes
        list.head.next = second;
        second.prev = list.head;
        second.next = third;
        third.prev = second;

        // Traverse the doubly linked list in forward direction
        System.out.println("Forward traversal:");
        list.traverseForward();

        // Traverse the doubly linked list in backward direction
        System.out.println("Backward traversal:");
        list.traverseBackward();
    }
}
