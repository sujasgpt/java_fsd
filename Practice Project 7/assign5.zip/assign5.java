package pracassign;

public class assign5 {

}
