package pracassign;

public class assign6 {

}
