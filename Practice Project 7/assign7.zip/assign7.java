package pracassign;

public class assign7 {

}
