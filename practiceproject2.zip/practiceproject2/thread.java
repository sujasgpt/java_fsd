package practiceproject2;

public class thread extends Thread implements Runnable {

	    // Constructor
	    public thread() {
	        super("MyThread");
	        System.out.println("Creating " + getName());
	    }

	    // Implementing the run() method of the Runnable interface
	    public void run() {
	        System.out.println("Running " + getName());
	        try {
	            for (int i = 1; i <= 5; i++) {
	                System.out.println("Thread: " + getName() + ", Count: " + i);
	                Thread.sleep(1000);
	            }
	        } catch (InterruptedException e) {
	            System.out.println(getName() + " interrupted.");
	        }
	        System.out.println(getName() + " exiting.");
	    }

	    // Main method
	    public static void main(String args[]) {
	    	thread myThread = new thread();
	        myThread.start();
	    }
	}

