package practiceproject2;


public class SleepandWaitDemo {

    public static void main(String[] args) {
        
        // Sleep Demo
        try {
            System.out.println("Before sleep...");
            Thread.sleep(5000); // Sleep for 5 seconds
            System.out.println("After sleep...");
        } catch (InterruptedException e) {
            System.out.println("Interrupted!");
        }
        
        // Wait Demo
        final Object lock = new Object(); // Object used for synchronization
        
        new Thread(() -> {
            synchronized (lock) {
                System.out.println("Thread 1 acquired the lock...");
                try {
                    lock.wait(); // Wait for notification
                } catch (InterruptedException e) {
                    System.out.println("Thread 1 interrupted!");
                }
                System.out.println("Thread 1 released the lock...");
            }
        }).start();
        
        new Thread(() -> {
            synchronized (lock) {
                System.out.println("Thread 2 acquired the lock...");
                lock.notify(); // Notify waiting thread
                System.out.println("Thread 2 released the lock...");
            }
        }).start();
    }
}
