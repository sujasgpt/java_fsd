package practiceproject2;

public class COOop {
    // Data members
    private String name;
    private int age;
    private String gender;

    // Constructor
    public COOop(String name, int age, String gender) {
        this.name = name;
        this.age = age;
        this.gender = gender;
    }

    // Getter methods
    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }

    // Setter methods
    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    // Behavior methods
    public void greet() {
        System.out.println("Hello, my name is " + name + " and I am " + age + " years old.");
    }

    public void celebrateBirthday() {
        age++;
        System.out.println("Happy birthday to me! I am now " + age + " years old.");
    }

    // Main method
    public static void main(String[] args) {
        // Create a new Person object
    	COOop person = new COOop("Alice", 25, "female");

        // Use the object's behavior methods
        person.greet();
        person.celebrateBirthday();

        // Demonstrate the principles of inheritance and polymorphism
        COOop anotherPerson = new Student("Bob", 20, "male", "Computer Science");
        anotherPerson.greet();
    }
}

class Student extends COOop {
    // Additional data member
    private String major;

    // Constructor
    public Student(String name, int age, String gender, String major) {
        super(name, age, gender);
        this.major = major;
    }

    // Getter and setter for the major data member
    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    // Override the greet method
    public void greet() {
        System.out.println("Hello, my name is " + getName() + " and I am a " + major + " student.");
    }
}