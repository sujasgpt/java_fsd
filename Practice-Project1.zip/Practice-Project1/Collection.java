package assested_project_java;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class Collection {

	public static void main(String[] args) {
		// Create an ArrayList and add some elements
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("apple");
        arrayList.add("banana");
        arrayList.add("cherry");
        arrayList.add("date");

        // Print out the elements in the ArrayList
        System.out.println("ArrayList:");
        for (String element : arrayList) {
            System.out.println(element);
        }

        // Create a HashSet and add some elements
        HashSet<Integer> hashSet = new HashSet<>();
        hashSet.add(10);
        hashSet.add(20);
        hashSet.add(30);
        hashSet.add(40);

        // Print out the elements in the HashSet
        System.out.println("\nHashSet:");
        for (Integer element : hashSet) {
            System.out.println(element);
        }

        // Create a HashMap and add some key-value pairs
        HashMap<String, Integer> hashMap = new HashMap<>();
        hashMap.put("apple", 1);
        hashMap.put("banana", 2);
        hashMap.put("cherry", 3);
        hashMap.put("date", 4);

        // Print out the key-value pairs in the HashMap
        System.out.println("\nHashMap:");
        for (String key : hashMap.keySet()) {
            System.out.println(key + " => " + hashMap.get(key));
        }
	}

}
