package assested_project_java;

public class Array {

	public static void main(String[] args) {
		// Create an array of integers
        int[] numbers = { 2, 3, 5, 7, 11 };

        // Print the elements of the array
        for (int i = 0; i < numbers.length; i++) {
            System.out.println("Element " + i + ": " + numbers[i]);
        }

        // Sum the elements of the array
        int sum = 0;
        for (int i = 0; i < numbers.length; i++) {
            sum += numbers[i];
        }
        System.out.println("Sum: " + sum);

        // Find the maximum element of the array
        int max = numbers[0];
        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] > max) {
                max = numbers[i];
            }
        }
        System.out.println("Max: " + max);

	}

}
