package assested_project_java;

import java.util.HashMap;
import java.util.Map;


public class Map {

	public static void main(String[] args) {
		
		// Create a HashMap and add some key-value pairs
        Map<String, Integer> hashMap = new HashMap<>();
        hashMap.put("apple", 1);
        hashMap.put("banana", 2);
        hashMap.put("cherry", 3);
        hashMap.put("date", 4);

        // Print out the key-value pairs in the HashMap
        System.out.println("HashMap:");
        for (String key : hashMap.keySet()) {
            System.out.println(key + " => " + hashMap.get(key));
        }

        // Get the value associated with the key "banana"
        int bananaValue = hashMap.get("banana");
        System.out.println("\nThe value associated with 'banana' is " + bananaValue);

        // Check if the map contains a key
        boolean containsKey = hashMap.containsKey("apple");
        System.out.println("\nDoes the map contain the key 'apple'? " + containsKey);

        // Check if the map contains a value
        boolean containsValue = hashMap.containsValue(4);
        System.out.println("\nDoes the map contain the value 4? " + containsValue);
		    }
	}

