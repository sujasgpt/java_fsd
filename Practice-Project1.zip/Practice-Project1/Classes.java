package assested_project_java;

public class Classes {

	public static void main(String[] args) {
		// Create an instance of the outer class
		Classes outer = new Classes();

        // Create an instance of the inner class
        InnerClass inner = outer.new InnerClass();

        // Access the inner class's fields and methods
        System.out.println("Inner field: " + inner.innerField);
        inner.innerMethod();

        // Access the outer class's fields and methods from the inner class
        inner.accessOuter();
	}
		private int outerField = 10;

	    public void outerMethod() {
	        System.out.println("Outer method");
	    }

	    // Inner class
	    public class InnerClass {
	        private int innerField = 20;

	        public void innerMethod() {
	            System.out.println("Inner method");
	        }

	        public void accessOuter() {
	            System.out.println("Accessing outer field: " + outerField);
	            outerMethod();
	        }
	    }

}

