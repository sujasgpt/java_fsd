package assested_project_java;

public class methods_and_impletation {

	public static void main(String[] args) {
		// Call the printHello method with no arguments
        printHello();

        // Call the printGreeting method with a string argument
        printGreeting("Sujas");

        // Call the addNumbers method with two integer arguments
        int sum = addNumbers(5, 10);
        System.out.println("Sum: " + sum);

        // Call the isEven method with an integer argument
        boolean isEven = isEven(6);
        System.out.println("Is even? " + isEven);
    }

    // Method that prints "Hello"
    public static void printHello() {
        System.out.println("Hello");
    }

    // Method that prints a greeting with the given name
    public static void printGreeting(String name) {
        System.out.println("Hello, " + name + "!");
    }

    // Method that returns the sum of two numbers
    public static int addNumbers(int a, int b) {
        return a + b;
    }

    // Method that returns true if the given number is even, false otherwise
    public static boolean isEven(int number) {
        return number % 2 == 0;
    }

	}
