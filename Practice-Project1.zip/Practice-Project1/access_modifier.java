package assested_project_java;

public class access_modifier {

	public static void main(String[] args) {
		
		class Person {
		    // Private fields can only be accessed within the same class
		    private String name;
		    private int age;

		    // Public methods can be accessed from anywhere
		    public String getName() {
		        return name;
		    }

		    public void setName(String name) {
		        this.name = name;
		    }

		    public int getAge() {
		        return age;
		    }

		    public void setAge(int age) {
		        this.age = age;
		    }
		}
	        // Create an instance of the Person class
	        Person person = new Person();

	        // Set the values of the fields using public methods
	        person.setName("Rajat");
	        person.setAge(23);

	        // Get the values of the fields using public methods
	        String name = person.getName();
	        int age = person.getAge();

	        // Print the values of the fields
	        System.out.println("Name: " + name);
	        System.out.println("Age: " + age);
	    }
}

