package assested_project_java;

public class Constructor_and_types {
	private int x;
    private int y;

    // Default constructor
    public Constructor_and_types() {
        this.x = 0;
        this.y = 0;
    }

    // Parameterized constructor
    public Constructor_and_types(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Copy constructor
    public Constructor_and_types(Constructor_and_types other) {
        this.x = other.x;
        this.y = other.y;
    }

    // Main method to test the constructors
    public static void main(String[] args) {
        // Create an object using the default constructor
    	Constructor_and_types obj1 = new Constructor_and_types();
        System.out.println("x = " + obj1.x + ", y = " + obj1.y);

        // Create an object using the parameterized constructor
        Constructor_and_types obj2 = new Constructor_and_types(5, 10);
        System.out.println("x = " + obj2.x + ", y = " + obj2.y);

        // Create an object using the copy constructor
        Constructor_and_types obj3 = new Constructor_and_types(obj2);
        System.out.println("x = " + obj3.x + ", y = " + obj3.y);
    }
}
