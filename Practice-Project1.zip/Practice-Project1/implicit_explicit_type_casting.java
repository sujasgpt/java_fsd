package assested_project_java;

public class implicit_explicit_type_casting {

	public static void main(String[] args) {
		// Implicit type casting - automatic conversion of smaller data type to larger data type
	      int x = 10;
	      double y = x; // int is automatically converted to double
	      System.out.println("Implicit type casting: x = " + x + ", y = " + y);
	      
	      // Explicit type casting - manual conversion of larger data type to smaller data type
	      double a = 10.5;
	      int b = (int) a; // double is manually converted to int
	      System.out.println("Explicit type casting: a = " + a + ", b = " + b);
	}

}
