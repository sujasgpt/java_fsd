package assested_project_java;

public class String_conversion {

	public static void main(String[] args) {
		String str = "Hello, world!";
        StringBuffer buffer = new StringBuffer(str);
        StringBuilder builder = new StringBuilder(str);
        
        System.out.println("Original string: " + str);
        System.out.println("StringBuffer conversion: " + buffer.toString());
        System.out.println("StringBuilder conversion: " + builder.toString());

	}

}
