package PracticeProject4;

public class ExponentialSearch {
    public static int exponentialSearch(int[] array, int target) {
        int size = array.length;
        
        if (array[0] == target) {
            return 0; // Found the target at index 0
        }

        int i = 1;
        while (i < size && array[i] <= target) {
            i *= 2;
        }
        
        int left = i / 2;
        int right = Math.min(i, size - 1);

        return binarySearch(array, target, left, right);
    }
    
    public static int binarySearch(int[] array, int target, int left, int right) {
        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (array[mid] == target) {
                return mid; // Found the target at index mid
            }

            if (array[mid] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return -1; // Target not found in the array
    }

    public static void main(String[] args) {
        int[] array = {1, 2, 3, 5, 6, 7, 9};
        int target = 6;

        int result = exponentialSearch(array, target);
        if (result == -1) {
            System.out.println("Target not found in the array.");
        } else {
            System.out.println("Target found at index " + result + ".");
        }
    }
}
