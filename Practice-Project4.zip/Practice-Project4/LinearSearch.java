package PracticeProject4;

public class LinearSearch {
    public static int linearSearch(int[] array, int target) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == target) {
                return i; // Found the target at index i
            }
        }
        return -1; // Target not found in the array
    }

    public static void main(String[] args) {
        int[] array = {5, 9, 3, 7, 2, 1, 6};
        int target = 7;

        int result = linearSearch(array, target);
        if (result == -1) {
            System.out.println("Target not found in the array.");
        } else {
            System.out.println("Target found at index " + result + ".");
        }
    }
}