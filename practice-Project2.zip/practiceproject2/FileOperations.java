package practiceproject2;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class FileOperations {

    public static void main(String[] args) {
        // Create a new file
        File file = new File("example.txt");
        try {
            boolean success = file.createNewFile();
            if (success) {
                System.out.println("File created successfully!");
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred while creating the file.");
            e.printStackTrace();
        }

        // Read the contents of the file
        try {
            byte[] content = Files.readAllBytes(file.toPath());
            String text = new String(content);
            System.out.println("File contents: " + text);
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file.");
            e.printStackTrace();
        }

        // Update the contents of the file
        String newText = "This is new text that replaces the old text.";
        try {
            Files.write(file.toPath(), newText.getBytes());
            System.out.println("File updated successfully!");
        } catch (IOException e) {
            System.out.println("An error occurred while updating the file.");
            e.printStackTrace();
        }

        // Delete the file
        boolean deleted = file.delete();
        if (deleted) {
            System.out.println("File deleted successfully!");
        } else {
            System.out.println("Failed to delete the file.");
        }
    }

}
