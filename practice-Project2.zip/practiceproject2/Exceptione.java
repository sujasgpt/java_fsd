package practiceproject2;

public class Exceptione {
    
    public static void main(String[] args) {
        try {
            int result = divide(10, 0);
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Exception caught: " + e.getMessage());
        } catch (CustomException e) {
            System.out.println("Exception caught: " + e.getMessage());
        } finally {
            System.out.println("Finally block executed.");
        }
    }
    
    public static int divide(int a, int b) throws CustomException {
        if (b == 0) {
            throw new ArithmeticException("Cannot divide by zero.");
        } else if (a % b != 0) {
            throw new CustomException("Result is not an integer.");
        }
        return a / b;
    }
    
    public static class CustomException extends Exception {
        public CustomException(String message) {
            super(message);
        }
    }
}
