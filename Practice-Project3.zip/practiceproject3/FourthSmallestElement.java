package practiceproject3;

import java.util.Arrays;

public class FourthSmallestElement {

    public static int findFourthSmallest(int[] nums) {
        if (nums == null || nums.length < 4) {
            throw new IllegalArgumentException("Input list should have at least four elements");
        }

        // Sort the array in ascending order
        Arrays.sort(nums);

        // The fourth smallest element will be at index 3
        return nums[3];
    }

    public static void main(String[] args) {
        int[] nums = {9, 5, 2, 7, 1, 8, 3, 6, 4};
        int fourthSmallest = findFourthSmallest(nums);
        System.out.println("The fourth smallest element is: " + fourthSmallest);
    }
}