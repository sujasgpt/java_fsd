package practiceproject3;

public class RangeSum {

    public static int findRangeSum(int[] nums, int L, int R) {
        if (nums == null || L > R || R >= nums.length) {
            throw new IllegalArgumentException("Invalid input range");
        }

        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += nums[i];
        }

        return sum;
    }

    public static void main(String[] args) {
        int[] nums = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        int L = 2;
        int R = 6;
        int rangeSum = findRangeSum(nums, L, R);
        System.out.println("The sum of elements in the range [" + L + ", " + R + "] is: " + rangeSum);
    }
}