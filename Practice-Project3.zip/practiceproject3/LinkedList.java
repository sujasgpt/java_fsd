package practiceproject3;

public class LinkedList {

    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    static Node deleteFirstOccurrence(Node head, int key) {
        if (head == null) {
            return null;
        }

        // If the key is found at the head, move head to the next node
        if (head.data == key) {
            return head.next;
        }

        Node prev = head;
        Node current = head.next;

        // Traverse the linked list to find the key
        while (current != null) {
            if (current.data == key) {
                // Key found, delete the node by adjusting the pointers
                prev.next = current.next;
                break;
            }

            prev = current;
            current = current.next;
        }

        return head;
    }

    static void printLinkedList(Node head) {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Node head = new Node(1);
        head.next = new Node(2);
        head.next.next = new Node(3);
        head.next.next.next = new Node(4);
        head.next.next.next.next = new Node(5);

        int key = 3;

        System.out.println("Original Linked List:");
        printLinkedList(head);

        head = deleteFirstOccurrence(head, key);

        System.out.println("Linked List after deleting first occurrence of " + key + ":");
        printLinkedList(head);
    }
}
