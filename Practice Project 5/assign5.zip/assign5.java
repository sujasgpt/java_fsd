package assignment26may;

import java.sql.*;

public class assign5 {
    // JDBC driver name and database URL
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/";

    // Database credentials
    static final String USER = "root";
    static final String PASS = "password";

    public static void main(String[] args) {
        Connection conn = null;
        Statement stmt = null;

        try {
            // Register JDBC driver
            Class.forName(JDBC_DRIVER);

            // Open a connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // Create a database
            System.out.println("Creating database...");
            stmt = conn.createStatement();
            String sql = "CREATE DATABASE mydatabase";
            stmt.executeUpdate(sql);
            System.out.println("Database created successfully!");

            // Select the newly created database
            sql = "USE mydatabase";
            stmt.executeUpdate(sql);
            System.out.println("Database selected successfully!");

            // Drop the database
            System.out.println("Dropping database...");
            sql = "DROP DATABASE mydatabase";
            stmt.executeUpdate(sql);
            System.out.println("Database dropped successfully!");
        } catch (SQLException se) {
            // Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            // Handle errors for Class.forName
            e.printStackTrace();
        } finally {
            // Close resources
            try {
                if (stmt != null)
                    stmt.close();
            } catch (SQLException se2) {
            } // Nothing we can do
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        System.out.println("Goodbye!");
    }
}

