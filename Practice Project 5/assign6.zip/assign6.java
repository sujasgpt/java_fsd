package assignment26may;

public class assign6 {

}
